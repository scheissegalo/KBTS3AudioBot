<template>
	<div class="notification is-warning">Hello</div>
</template>

<script lang="ts">
import Vue from "vue";

export default Vue.component("playback-info", {
	props: {}
});
</script>
