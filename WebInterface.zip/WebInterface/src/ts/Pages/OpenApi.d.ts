declare const SwaggerUIStandalonePreset: any;
declare const SwaggerUIBundle: any;
