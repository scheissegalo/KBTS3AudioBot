export enum SpacerType {
	None = 0,
	CSpacer,
	RSpacer,
	StarSpacer
}
