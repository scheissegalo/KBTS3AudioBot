export enum TargetSendMode {
	None = 0,
	Voice,
	Whisper,
	WhisperGroup,
}
