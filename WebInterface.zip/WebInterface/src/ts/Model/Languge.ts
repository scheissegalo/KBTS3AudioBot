export default {
	"cs": "Czech",
	"da": "Danish",
	"en": "English",
	"fr": "French",
	"de": "German [Deutsch]",
	"hu": "Hungarian",
	"pl": "Polish",
	"ru": "Russian [Русский]",
	"es": "Spanish",
	"es-ar": "Spanish (Argentinia)",
	"th": "Thai",
};
