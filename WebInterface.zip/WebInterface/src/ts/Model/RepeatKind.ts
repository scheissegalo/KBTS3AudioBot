export enum RepeatKind {
	Off = 0,
	One,
	All,
}
