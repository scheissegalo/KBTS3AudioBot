export enum PlayState {
	Off,
	Playing,
	Paused,
}
