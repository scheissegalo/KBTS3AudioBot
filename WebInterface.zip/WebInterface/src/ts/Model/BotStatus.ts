export enum BotStatus {
	Offline,
	Connecting,
	Connected
}
